$(document).ready(function(){
    $('.slider').slick({
    arrows:true,
    dots:true,
    adaptiveHeight:true,
    speed:1000,
    easing:'linear',
    autoplay:true,
    autoplaySpeed:2000,
    pauseOnFocus:false,
    pauseOnHover:false,
    // fade:true,
    });
});

$(document).ready(function(){
    $('.slider-mob').slick({
    arrows:true,
    dots:true,
    adaptiveHeight:true,
    speed:1000,
    easing:'linear',
    autoplay:true,
    autoplaySpeed:2000,
    pauseOnFocus:false,
    pauseOnHover:false,
    // fade:true,
    });
});